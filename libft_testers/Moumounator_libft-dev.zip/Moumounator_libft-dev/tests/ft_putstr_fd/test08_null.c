#include <stdio.h>
#include <string.h>

int ft_putstr_fd(char *str, int fd);

int main(void) {
	ft_putstr_fd(NULL, 1);
	return (0);
}