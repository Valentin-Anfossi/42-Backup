#include <stdio.h>
#include <string.h>

void ft_putendl_fd(char *str, int fd);

int main(void) {
	ft_putendl_fd(NULL, 1);
	return (0);
}
