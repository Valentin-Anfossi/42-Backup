/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_error.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vanfossi <vanfossi@student.42nice.fr>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/03 16:19:16 by vanfossi          #+#    #+#             */
/*   Updated: 2024/12/03 18:02:34 by vanfossi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

//WHAT IS MY PURPOSE ? YOU PRINT ERROR. OMG
int print_error(void)
{
	printf("Error.\n");
	return(1);
}